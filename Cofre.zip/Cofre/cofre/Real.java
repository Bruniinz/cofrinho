// Aluno : Bruno Telles -  RU : 4318152
package cofre;

class Real extends Moeda {
       public Real() { // construtor da classe Real
        super("Real", 1.00);
    }

    
    public double converterParaReal() {  // como o real nao precisa ser convertido, a linha de baixo vai retornar o valor do real
        return valor;
    }
}
