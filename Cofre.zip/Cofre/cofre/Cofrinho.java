// Aluno : Bruno Telles -  RU : 4318152
package cofre;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;


class Cofrinho { // classe do Cofrinho de moedas
    private ArrayList<Moeda> moedas;

    
    public Cofrinho() { // Construtor da classe Cofrinho
        moedas = new ArrayList<>();
    }

   
    public void adicionarMoedas(int quantidade, Moeda moeda) {  // para adicionar moedas no cofrinho
        for (int i = 0; i < quantidade; i++) {
            moedas.add(moeda);
        }
        System.out.println("Moedas adicionadas!");
    }

    
    public void removerMoedas(int quantidade, Class<? extends Moeda> moedaClasse) { // para remover moedas do cofrinho
        int contadorRemovidas = 0;
        Iterator<Moeda> iterator = moedas.iterator();

        while (iterator.hasNext() && contadorRemovidas < quantidade) {
            Moeda moeda = iterator.next();
            if (moeda.getClass().equals(moedaClasse)) {
                iterator.remove();
                contadorRemovidas++;
            }
        }

        System.out.println("Moedas removidas!");
    }

    
    public void listarMoedas() { // para listar as moedas que tem no cofrinho
        System.out.println("Moedas no seu Cofrinho:");
        HashMap<String, Integer> quantidadeMoedas = new HashMap<>();

        
        for (Moeda moeda : moedas) { // para contar a quantidade de cada moeda
            String nomeMoeda = moeda.getNome();
            quantidadeMoedas.put(nomeMoeda, quantidadeMoedas.getOrDefault(nomeMoeda, 0) + 1);
        }

        
        for (String nomeMoeda : quantidadeMoedas.keySet()) { // Exibe a quantidade total de cada moeda
            int quantidade = quantidadeMoedas.get(nomeMoeda);
            System.out.println(nomeMoeda + " - " + quantidade);
        }
    }

    
    public double calcularTotalEmReal() { // Calcula e converte para real o total de moedas do cofrinho
        double total = 0.0;
        for (Moeda moeda : moedas) {
            total += moeda.converterParaReal();
        }
        return total;
    }
}
