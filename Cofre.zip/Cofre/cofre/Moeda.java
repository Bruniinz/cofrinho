// Aluno : Bruno Telles -  RU : 4318152
package cofre;
abstract class Moeda {
    protected String nome;
    protected double valor;

    
    public Moeda(String nome, double valor) { // Construtor da classe moeda
        this.nome = nome;
        this.valor = valor;
    }

   
    public String getNome() { // para obter o nome da moeda
        return nome;
    }

    
    public double getValor() { // para obter o valor da moeda em relação ao Real
        return valor;
    }

    
    public abstract double converterParaReal(); // para converter o valor da moeda para real
}
