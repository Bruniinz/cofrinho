// Aluno : Bruno Telles -  RU : 4318152
package cofre;
class Dolar extends Moeda {
        public Dolar() { // Construtor da classe Dolar
        super("Dólar", 1.00);
    }

    
    public double converterParaReal() { // para converter o valor do dolar pra real
        return valor * 4.00; // retorna o valor convertido
    }
}
