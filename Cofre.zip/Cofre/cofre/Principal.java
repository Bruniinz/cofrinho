// Aluno : Bruno Telles -  RU : 4318152
package cofre;
import java.util.Scanner;


public class Principal { // Classe principal com o método main pra implementar interface do usuario
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);  // linhas 6 e 7 são variaveis
        Cofrinho cofrinho = new Cofrinho();

        int opcao;
        do { // fazendo o primeiro menu de opções
            System.out.println("=== Menu ===");
            System.out.println("1 - Adicionar moedas ao cofrinho");
            System.out.println("2 - Remover moeda do cofrinho");
            System.out.println("3 - Listar moedas do cofrinho");
            System.out.println("4 - Calcular total em Real");
            System.out.println("5 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1: //  opção para adicionar moedas 
                    System.out.print("Quantas moedas deseja adicionar? ");
                    int quantidade = scanner.nextInt();
                    System.out.println("Escolha a moeda:");
                    System.out.println("1 - Dólar");
                    System.out.println("2 - Euro");
                    System.out.println("3 - Real");
                    int escolha = scanner.nextInt();

                    Moeda moeda;
                    switch (escolha) {
                        case 1:
                            moeda = new Dolar();
                            break;
                        case 2:
                            moeda = new Euro();
                            break;
                        case 3:
                            moeda = new Real();
                            break;
                        default:
                            System.out.println("Opção inválida.");
                            continue;
                    }

                    cofrinho.adicionarMoedas(quantidade, moeda);
                    break;
                case 2: // opção para remover as moedas
                    System.out.print("Quantas moedas deseja remover? ");
                    int quantidadeRemover = scanner.nextInt();
                    System.out.println("De qual moeda gostaria de remover?");
                    System.out.println("1 - Dólar");
                    System.out.println("2 - Euro");
                    System.out.println("3 - Real");
                    int escolhaMoedaRemover = scanner.nextInt();

                    Class<? extends Moeda> moedaClasseRemover;
                    switch (escolhaMoedaRemover) {
                        case 1:
                            moedaClasseRemover = Dolar.class;
                            break;
                        case 2:
                            moedaClasseRemover = Euro.class;
                            break;
                        case 3:
                            moedaClasseRemover = Real.class;
                            break;
                        default:
                            System.out.println("Opção inválida.");
                            continue;
                    }

                    cofrinho.removerMoedas(quantidadeRemover, moedaClasseRemover);
                    break;
                case 3: // opção para listar as moedas
                    cofrinho.listarMoedas();
                    break;
                case 4: // opção para calcular o total de moedas em real
                    double totalReal = cofrinho.calcularTotalEmReal();
                    System.out.println("Total em Real: R$" + totalReal);
                    break;
                case 5:  // opção para sair do programa
                    System.out.println("Saindo do programa.");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }

            System.out.println();
        } while (opcao != 5);

        scanner.close();
    }
}
