// Aluno : Bruno Telles -  RU : 4318152
package cofre;
class Euro extends Moeda {
        public Euro() { // Construtor da Classe Euro
        super("Euro", 1.00);
    }

    
    public double converterParaReal() { // converte o valor do euro para o real
        return valor * 5.00;  // retorna o valor em real
    }
}
